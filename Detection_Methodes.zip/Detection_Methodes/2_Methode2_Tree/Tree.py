from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score, classification_report
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
import seaborn as sns 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import pickle
import time 
from sklearn.tree import plot_tree

# Dataset
pickle_in = open("X.pickle", "rb")
X = pickle.load(pickle_in) # 3D 
pickle_in = open("y.pickle", "rb")
y = pickle.load(pickle_in) # 1D 
pickle_in = open("data.pickle", "rb")
data = pickle.load(pickle_in) # 2-D, Data matrix will serve as X


# Classification
print('# of Samples:', len(y))
print('# of Without A Mask:', (y == 0).sum())
print('# of With A Mask:', (y == 1).sum())
print('# of Incorrectly Worn Mask:', (y == 2).sum())

# ............................................................................

# Dataframe
cols = []
for i in range(0, len(data[0])):
    cols.append("P" + str(i))

numpy_data = data
X = pd.DataFrame(data=numpy_data, columns=[cols])
y = pd.DataFrame(data=y, columns=["Mask_Target"])


# Tailles
print('\nImage Data Shape:', X.shape) # Feature sets are 64X64 images flatten to a 4096 feature vector
print('Image Data Shape Features:', data.shape)
print('Image Data Shape Target:', y.shape)

# ............................................................................

# Normalisation
X = X / 255.0


# Données Train et Test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
print('Length of our Training data: ', len(X_train), '\nLength of our Testing data: ', len(X_test))

# ............................................................................

" Decision Tree : NO HYPERPARAMETER TUNING "

# Modèle
# Initialize Decision Trees model, No hyperparameter Tuning
decision_trees = DecisionTreeClassifier()
decision_trees.fit(X_train, y_train.values.ravel())
predictions_set1 = decision_trees.predict(X_test)

# Enregistrement des prédictions
pickle_out = open("predictions_set2_dt.pickle", "wb")
pickle.dump(predictions_set1, pickle_out)
pickle_out.close()

# ............................................................................

# Matrice de confusion
cm = confusion_matrix(y_test, predictions_set1)
plt.figure(figsize=(9,9))
sns.heatmap(cm,annot=True, fmt='.3f', linewidths=.5, square=True,cmap='Blues_r')
plt.ylabel('Actual label')
plt.xlabel('Predicted label')
title = 'Accuracy Score, No Hyperparameter Tuning: {0}'.format(accuracy_score(y_test, predictions_set1))
plt.title(title,size=15)
plt.show()


# Précisions
print('Decision Trees Precision: %.3f' % precision_score(y_test, predictions_set1, average='micro'))
print('Decision Trees Recall: %.3f' % recall_score(y_test, predictions_set1, average='micro'))
print('Decision Trees F1 Score: %.3f' % f1_score(y_test, predictions_set1, average='micro'))


# Classification Report
# RECALL
# CLASS 0: NO MASK
# CLASS 1: CORRECT WEAR OF MASK
# CLASS 2: INCORRECT WEAR OF MASK

print("\nClassification Report\n", classification_report(y_test, predictions_set1))


# Visualiation de l'arbre
plot_tree(decision_trees)
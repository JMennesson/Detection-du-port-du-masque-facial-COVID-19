import numpy as np 
import sklearn
import sklearn.naive_bayes
from sklearn.model_selection import train_test_split
import pickle
import cv2
from cv2 import cv2
import matplotlib.pyplot as plt
import seaborn as sns

sns.set()

# Dataset 
pickle_in = open("X.pickle", "rb")
X = pickle.load(pickle_in)
pickle_in = open("y.pickle", "rb")
y = pickle.load(pickle_in)

# Labels
CATEGORIES = ['Without Mask', 'Wearing Mask', 'Incorrectly Wearing Mask']

# Dimension : 1D
X = X.reshape(-1, 64*64)

# Normalisation
X = X / 255.0

# Split Datatset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# .............................................................................

" GaussianNB "
 
# Modèle
gaussianNB_model = sklearn.naive_bayes.GaussianNB()
# Training
gaussianNB_model.fit(X_train, y_train)
# Prediction
gnb_y_pred = gaussianNB_model.predict(X_test)


# Précisions
print('GaussianNB Metrics')
accuracy = sklearn.metrics.accuracy_score(y_test, gnb_y_pred)
print('Accuracy: %f' % accuracy)
recall = sklearn.metrics.recall_score(y_test, gnb_y_pred, average='micro')
print('Recall: %f' % recall)
f1_score = sklearn.metrics.f1_score(y_test, gnb_y_pred, average='micro')
print('F1 Score: %f' % f1_score, end='\n\n')


# Matrice de confusion
cm = sklearn.metrics.confusion_matrix(y_test, gnb_y_pred)
plt.figure(figsize=(8,8), facecolor='w')
sns.heatmap(cm, annot=True, fmt='d', linewidths=.5, square=True,cmap='Blues_r', yticklabels=CATEGORIES, xticklabels=CATEGORIES)
plt.title('Confusion Matrix for GaussianNB')

# .............................................................................

" MultinomialNB "
# Modèle
multinomialNB_model = sklearn.naive_bayes.MultinomialNB()
multinomialNB_model.fit(X_train, y_train)
mnb_y_pred = multinomialNB_model.predict(X_test)

# Précisions 
print('MultinomialNB Metrics')
accuracy = sklearn.metrics.accuracy_score(y_test, mnb_y_pred)
print('Accuracy: %f' % accuracy)
recall = sklearn.metrics.recall_score(y_test, mnb_y_pred, average='micro')
print('Recall: %f' % recall)
f1_score = sklearn.metrics.f1_score(y_test, mnb_y_pred, average='micro')
print('F1 Score: %f' % f1_score, end='\n\n')

# Matrice de confusion 
cm = sklearn.metrics.confusion_matrix(y_test, mnb_y_pred)
plt.figure(figsize=(8,8), facecolor='w')
sns.heatmap(cm, annot=True, fmt='d', linewidths=.5, square=True,cmap='Blues_r', yticklabels=CATEGORIES, xticklabels=CATEGORIES)
plt.title('Confusion Matrix for MultinomialNB')







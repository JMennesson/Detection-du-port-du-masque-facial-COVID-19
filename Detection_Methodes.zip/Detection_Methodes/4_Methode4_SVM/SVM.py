import pandas as pd
import numpy as np
import pickle
from sklearn import svm
from sklearn import metrics
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import seaborn as sns


# Dataset
pickle_in = open("X.pickle", "rb")
X = pickle.load(pickle_in)
pickle_in = open("y.pickle", "rb")
y = pickle.load(pickle_in)

# 1D
X = X.reshape(-1, 64*64)

# # #X et y pour 75%, 50%, et 25% du dataset
# X_75, X_extra, y_75, y_extra = train_test_split(X, y, train_size=.75)
# X_50, X_extra, y_50, y_extra = train_test_split(X, y, train_size=.50)
# X_25, X_extra, y_25, y_extra = train_test_split(X, y, train_size=.25)


# # Splitting en fonction du dataset
# #100%
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20)
# #75%
# #X_train, X_test, y_train, y_test = train_test_split(X_75, y_75, test_size=0.25)
# #50%
# #X_train, X_test, y_train, y_test = train_test_split(X_50, y_50, test_size=0.25)
# #25%
# #X_train, X_test, y_train, y_test = train_test_split(X_25, y_25, test_size=0.25)


# Modèle 
model_100 = svm.SVC()
model_100.fit(X_train, y_train) 
y_pred = model_100.predict(X_test)


# Précisions
accuracy = model_100.score(X_test, y_test)  
print("Accuracy %f" % accuracy)
metrics.accuracy_score(y_true=y_test, y_pred=y_pred)
print(metrics.classification_report(y_test, y_pred))


# Matrice de confusion 
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(9,9))
sns.heatmap(cm,annot=True, fmt='.3f', linewidths=.5, square=True,cmap='Reds_r')
plt.ylabel('Actual label')
plt.xlabel('Predicted label')
plt.title('Matrice de confusion pour 100% du dataset')







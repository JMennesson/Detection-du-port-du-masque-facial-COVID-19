from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score, classification_report
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV, RandomizedSearchCV
from sklearn.decomposition import PCA
import seaborn as sns 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import pickle
import time 
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold


# Dataset
pickle_in = open("X.pickle", "rb")
X = pickle.load(pickle_in)
pickle_in = open("y.pickle", "rb")
y = pickle.load(pickle_in)
pickle_in = open("data.pickle", "rb")
data = pickle.load(pickle_in) # Data Matrix will serve as X


# Rappel
# CLASS 0: NO MASK
# CLASS 1: CORRECT WEAR OF MASK
# CLASS 2: INCORRECT WEAR OF MASK

# ............................................................................

# Noms des colonnes du Dataframe 
cols = []
for i in range(0, len(data[0])):
    cols.append("P" + str(i))

# Convertion en Dataframe 
numpy_data = data
X = pd.DataFrame(data=numpy_data, columns=[cols])
# print(X.head())

y = pd.DataFrame(data=y, columns=["Mask_Target"])
# print(y.head())

# Affichage des tailles 
print('\nImage Data Shape:', X.shape)
print('Image Data Shape Features:', data.shape)
print('Image Data Shape Target:', y.shape)

# ............................................................................

# Dimension : 1D :  Au préalable pour l'affichage des courbes 
X = X.reshape(-1, 64*64)

# Normalisation des données
X = X / 255.0

# Découpage en données train et test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Taille des données d'entrainement 
print('Length of our Training data: ', len(X_train), '\nLength of our Testing data: ', len(X_test))

# ............................................................................

" KNN NO HYPERPARAMETER TUNING "

# Initialisation du modèle KNN
knn = KNeighborsClassifier()

# Fitting
knn.fit(X_train, y_train.values.ravel())

# Prediction
predictions_set1 = knn.predict(X_test)

# Sauvegarde des prédictions sous forme de pickle
pickle_out = open("predictions_set1.pickle", "wb")
pickle.dump(predictions_set1, pickle_out)
pickle_out.close()



# Affichage de la précision
print('KNN Accuracy: %.3f' % accuracy_score(y_test, predictions_set1))

# Affichage de la matrice de confusion
cm = confusion_matrix(y_test, predictions_set1)
plt.figure(figsize=(9,9))
sns.heatmap(cm,annot=True, fmt='.3f', linewidths=.5, square=True,cmap='Reds_r')
plt.ylabel('Actual label')
plt.xlabel('Predicted label')
all_sample_title = 'KNN No Hyperparameter Tuning / Accuracy Score: {0}'.format(accuracy_score(y_test, predictions_set1))
plt.title(all_sample_title,size=15)


# ............................................................................

" KNN HYPERPARAMETER TUNING " 

best_params = {'weights': 'distance', 'n_neighbors': 2, 'metric': 'manhattan'}

# Nouveau modèle KNN
b_knn = KNeighborsClassifier(**best_params)

b_knn.fit(X_train, y_train.values.ravel())

train_pred = b_knn.predict(X_train)
y_pred = b_knn.predict(X_test)

print('Accuracy Train: %.3f' % accuracy_score(y_train, train_pred))
print('Accuracy Test: %.3f' % accuracy_score(y_test, y_pred))
print("\nClassification Report\n", classification_report(y_test, y_pred))


# Matrice de confusion 
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(9,9))
sns.heatmap(cm,annot=True, fmt='.3f', linewidths=.5, square=True,cmap='Greens_r')
plt.ylabel('Actual label')
plt.xlabel('Predicted label')
title = 'KNN Hyperparameter Tuning /Accuracy Score Best Params: {0}'.format(accuracy_score(y_test, y_pred))
plt.title(title,size=15)


# ............................................................................

# Enregistrement du modèle performant 
filename = 'knn-face-mask-detection-model.pkl'

pickle.dump(b_knn, open(filename, 'wb'))
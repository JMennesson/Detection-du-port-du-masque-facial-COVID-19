from sklearn.model_selection import train_test_split
import numpy as np
import os
import PIL
import cv2
import pickle
import matplotlib.pyplot as plt

DIRECTORY = "C:/Users/clair/Desktop/GITHUB/Detection_Methodes/donnees/TrainTest/"

# 3 classes de prédiction 
CATEGORIES = ['WithoutMask', 'WithMask', 'IncorrectedWearMask']
IMG_SIZE = 64

# Données
X = []
# Labels(0,1,2)
y = []

# .............................................................................

# Extraction des features 
def create_data():
    for category in CATEGORIES:
        path = os.path.join(DIRECTORY, category)
        class_num_label = CATEGORIES.index(category)
        for img in os.listdir(path):
            try:
                img_array = cv2.imread(os.path.join(path,img), cv2.IMREAD_GRAYSCALE)
                img_array = cv2.resize(img_array, (IMG_SIZE,IMG_SIZE))
                X.append(img_array)
                y.append(class_num_label)
            except Exception as e:
                pass
            
create_data()

# .............................................................................

# Passage des données en array
SAMPLE_SIZE = len(y)
data = np.array(X).flatten().reshape(SAMPLE_SIZE, IMG_SIZE*IMG_SIZE) # pixel-features

# X et y en numpy array 
X = np.array(X).reshape(-1, IMG_SIZE, IMG_SIZE) # images
y = np.array(y) # target

print("Features, X shape: ", X.shape)
print("Target, y shape: ", y.shape)
print("Data shape: ", data.shape)

# .............................................................................

# Enregistrement des données sous forme de pickles 
pickle_out = open("X.pickle", "wb")
pickle.dump(X, pickle_out)
pickle_out.close()

pickle_out = open("y.pickle", "wb")
pickle.dump(y, pickle_out)
pickle_out.close()

pickle_out = open("data.pickle", "wb")
pickle.dump(data, pickle_out)
pickle_out.close()


# Chargement des pickles 
pickle_in = open("X.pickle", "rb")
X = pickle.load(pickle_in)
pickle_in = open("y.pickle", "rb")
y = pickle.load(pickle_in)
pickle_in = open("data.pickle", "rb")
data = pickle.load(pickle_in)

# .............................................................................


# Inventaire 
print('Number of Samples:', len(y))
print('Number of Without A Mask:', (y == 0).sum())
print('Number of With A Mask:', (y == 1).sum())
print('Number of Incorrected Wear Mask:', (y == 2).sum())

# .............................................................................


# Graphe illustratif de la répartition des images 
names = ['Without A Mask', 'With A Mask', 'Incorrected Wear Mask'] 
values = [(y == 0).sum(),(y == 1).sum(),(y == 2).sum()]
plt.title('Répartition des images du dataset en fonction de leur classe')
plt.ylabel('Nombres')
plt.bar(names, values)
plt.show() 




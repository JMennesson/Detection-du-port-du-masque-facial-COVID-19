import numpy as np
import matplotlib.pyplot as plt
import tensorflow
import sklearn
from sklearn.model_selection import train_test_split
import cv2
import seaborn as sns
import pickle
import os

# Dataset
pickle_in = open("X.pickle", "rb")
X = pickle.load(pickle_in)
pickle_in = open("y.pickle", "rb")
y = pickle.load(pickle_in)

# Labels
CATEGORIES = ['Without Mask', 'Wearing Mask', 'Incorrectly Wearing Mask']

# Redimensionnage
resized_X = []
for img in X:
    resized_X.append(cv2.resize(img, (64, 64)))
    
# Array
X = np.asarray(resized_X)
X = X.reshape(-1, 64, 64, 1)

# Normalisation
X = X / 255.0

# Dimension image
IMG_DIM = X.shape[1]
# print('IMG_DIM:',IMG_DIM)

# Données Train et Test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
print('Training Size:', len(X_train))
print('Testing  Size:', len(X_test))

# ............................................................................

# CNN Model
cnn_model = tensorflow.keras.models.Sequential()

# Convolution Layers & Maxpooling
cnn_model.add(tensorflow.keras.layers.Conv2D(filters=64, kernel_size=3, activation='relu', input_shape=(IMG_DIM, IMG_DIM, 1)))
cnn_model.add(tensorflow.keras.layers.Conv2D(filters=64, kernel_size=3, activation='relu'))
cnn_model.add(tensorflow.keras.layers.MaxPool2D())

cnn_model.add(tensorflow.keras.layers.Conv2D(filters=64, kernel_size=3, activation='relu'))
cnn_model.add(tensorflow.keras.layers.Conv2D(filters=64, kernel_size=3, activation='relu'))
cnn_model.add(tensorflow.keras.layers.MaxPool2D())

cnn_model.add(tensorflow.keras.layers.Conv2D(filters=64, kernel_size=3, activation='relu', input_shape=(IMG_DIM, IMG_DIM, 1)))
cnn_model.add(tensorflow.keras.layers.Conv2D(filters=64, kernel_size=3, activation='relu'))
cnn_model.add(tensorflow.keras.layers.MaxPool2D())

# Neural Nets
cnn_model.add(tensorflow.keras.layers.Flatten())

cnn_model.add(tensorflow.keras.layers.Dense(512, activation='relu'))
cnn_model.add(tensorflow.keras.layers.Dropout(0.3))
cnn_model.add(tensorflow.keras.layers.Dense(512, activation='relu'))
cnn_model.add(tensorflow.keras.layers.Dropout(0.3))
cnn_model.add(tensorflow.keras.layers.Dense(256, activation='relu'))
cnn_model.add(tensorflow.keras.layers.Dense(128, activation='relu'))
cnn_model.add(tensorflow.keras.layers.Dense(3, activation='softmax'))

cnn_model.summary()

# Compilation du modèle 
cnn_model.compile(optimizer=tensorflow.keras.optimizers.Adam(), loss='sparse_categorical_crossentropy', metrics=['acc'])

# ............................................................................

# Entrainement
epochs = 10
cnn_model.fit(X_train, y_train, epochs=epochs, validation_split=0.1)

# Prédiction
cnn_model.evaluate(X_test, y_test)
y_pred = np.argmax(cnn_model.predict(X_test), axis=-1)

# ............................................................................

# Matrice de confusion
cm = sklearn.metrics.confusion_matrix(y_test, y_pred)
plt.figure(figsize=(9, 9))
sns.heatmap(cm, annot=True, fmt='.0f', square=True, linewidths=.5, cmap='Blues_r')
plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.title('Matrice de Confusion')
plt.show()

# Classification Report 
print('Classification Report')
print(' ')
print(sklearn.metrics.classification_report(y_test, y_pred))

# ............................................................................

# Enregistrement du modèle 
path = "C:/Users/clair/GITHUB/Detection_Methodes/5_Methode5_CNN/CNN/"
cnn_model.save(path)

# To load
# model = tensorflow.keras.models.load_model("C:/Users/clair/GITHUB/Detection_Methodes/5_Methode5_CNN/CNN/")